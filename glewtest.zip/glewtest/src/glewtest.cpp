#include "class/test/Test.h"

int main(){
	Test *test=new Test();
	test->Mainloop();
    return 0;
}
