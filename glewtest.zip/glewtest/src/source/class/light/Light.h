#ifndef LIGHT_H_
#define LIGHT_H_
#include <GL/glew.h>
#include <glm/glm.hpp>
class Light {
public:
	Light();
	virtual ~Light();

};

#endif /* LIGHT_H_ */
