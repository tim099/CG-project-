#include <class/light/Light.h>

Light::Light() {

}
Light::~Light() {

}

