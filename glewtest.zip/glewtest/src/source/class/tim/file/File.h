#ifndef FILE_H_
#define FILE_H_
#include <fstream>
namespace Tim {

class File {
public:
	File();
	virtual ~File();
};

} /* namespace Tim */

#endif /* FILE_H_ */
