#include "class/tim/file/File.h"
#include "class/tim/string/String.h"
#include <cstring>
namespace Tim {

File::File() {

}
File::~File() {

}



} /* namespace Tim */
