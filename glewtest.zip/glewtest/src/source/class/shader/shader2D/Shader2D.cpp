#include "class/shader/shader2D/Shader2D.h"
#include "class/texture/Texture.h"
#include "class/buffer/Buffer.h"
Shader2D::Shader2D() {

}
Shader2D::~Shader2D() {

}
