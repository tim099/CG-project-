#ifndef SHADER2D_H_
#define SHADER2D_H_
#include <glm/glm.hpp>
#include "class/shader/Shader.h"

class Texture;
class Shader2D : public Shader{
public:
	Shader2D();
	virtual ~Shader2D();

};

#endif /* SHADER2D_H_ */
