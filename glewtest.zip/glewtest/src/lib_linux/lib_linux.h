#ifndef __LIB_LINUX_J
#define __LIB_LINUX_J

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#endif
